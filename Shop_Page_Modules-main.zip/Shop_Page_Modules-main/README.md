# Modules in Shop
This is just a purchase template using simply html, css and basic elements without boostrap but an original html structure along with css.

I'm developing a web site and I decided to create elements for a shopping site like a product panel, I just didn't use Javascript or any other language except Html, pure css
